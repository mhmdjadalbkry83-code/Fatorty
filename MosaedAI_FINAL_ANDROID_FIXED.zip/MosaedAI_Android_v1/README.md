# Mosaed AI — مساعد AI

نسخة أولى لتطبيق Android مع خادم وسيط آمن.

## المعمارية
Android → /api/chat → الخادم الوسيط → OpenAI Responses API

لا يتم وضع مفتاح OpenAI داخل APK.

## الملفات المهمة
- `app/.../AiApiClient.kt` عميل Android للاتصال بالخادم.
- `server/server.js` الخادم الوسيط.
- `server/.env.example` مثال لمتغيرات البيئة.

## ملاحظة
قبل الاستخدام الحقيقي غيّر `CHAT_URL` في `AiApiClient.kt` إلى رابط الخادم المنشور.


## v9 additions
- Settings button.
- Clear all saved conversations with confirmation.
- Existing chat, image, voice, and text-to-speech features retained.


## v10 branding
- Added MOSAED AI branded splash artwork.
- Added branded launcher icon asset.
- Added promotional showcase artwork generated for the app concept.
