package com.mosaed.ai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

object AiApiClient {
    private const val CHAT_URL = "https://YOUR_SERVER_URL/api/chat"
    private const val IMAGE_URL = "https://YOUR_SERVER_URL/api/analyze-image"

    fun sendMessage(message: String, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        postJson(CHAT_URL, JSONObject().put("message", message), onSuccess, onError)
    }

    fun analyzeImage(
        imageDataUrl: String,
        prompt: String = "حلل الصورة واشرح ما يظهر فيها بالعربية.",
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val body = JSONObject()
            .put("imageData", imageDataUrl)
            .put("prompt", prompt)
        postJson(IMAGE_URL, body, onSuccess, onError)
    }

    private fun postJson(
        endpoint: String,
        body: JSONObject,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        thread {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    connectTimeout = 15_000
                    readTimeout = 60_000
                    doOutput = true
                }

                connection.outputStream.use {
                    it.write(body.toString().toByteArray(Charsets.UTF_8))
                }

                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val json = if (text.isNotBlank()) JSONObject(text) else JSONObject()

                if (code in 200..299) {
                    onSuccess(json.optString("reply", "لم يصل رد من المساعد."))
                } else {
                    onError(json.optString("error", "تعذر الاتصال بالخادم."))
                }
            } catch (e: Exception) {
                onError(e.message ?: "خطأ في الاتصال.")
            } finally {
                connection?.disconnect()
            }
        }
    }
}
