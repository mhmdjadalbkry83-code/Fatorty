package com.mosaed.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var messagesContainer: LinearLayout
    private lateinit var input: EditText
    private lateinit var sendButton: Button
    private lateinit var imageButton: Button
    private lateinit var voiceButton: Button
    private lateinit var tts: TextToSpeech
    private lateinit var chatTitle: TextView

    private var lastReply = ""
    private var currentChatId = ""
    private val prefsName = "mosaed_chats"
    private val indexKey = "chat_index"

    companion object {
        private const val PICK_IMAGE = 2001
        private const val SPEECH_REQUEST = 2002
        private const val RECORD_AUDIO_REQUEST = 2003
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        messagesContainer = findViewById(R.id.messagesContainer)
        input = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)
        imageButton = findViewById(R.id.imageButton)
        voiceButton = findViewById(R.id.voiceButton)
        chatTitle = findViewById(R.id.chatTitle)
        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.replayButton).setOnClickListener { speakReply(lastReply) }
        findViewById<Button>(R.id.newChatButton).setOnClickListener { newChat() }
        findViewById<Button>(R.id.historyButton).setOnClickListener { showHistory() }

        newChat()
        sendButton.setOnClickListener { sendText(input.text.toString().trim()) }
        imageButton.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }, PICK_IMAGE)
        }
        voiceButton.setOnClickListener { startVoiceInput() }
    }

    private fun sendText(message: String) {
        if (message.isEmpty()) return
        if (currentChatId.isEmpty()) currentChatId = "chat_${System.currentTimeMillis()}"
        if (chatTitle.text == "محادثة جديدة") chatTitle.text = message.take(28)

        addAndSaveMessage("أنت: $message")
        input.text.clear()
        setBusy(true)
        addMessage("مساعد AI: جاري التفكير...")

        AiApiClient.sendMessage(message, { reply ->
            runOnUiThread {
                replaceLastMessage("مساعد AI: $reply")
                lastReply = reply
                saveCurrentChat()
                speakReply(reply)
                setBusy(false)
            }
        }, { error ->
            runOnUiThread {
                replaceLastMessage("مساعد AI: حصل خطأ في الاتصال.")
                saveCurrentChat()
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
                setBusy(false)
            }
        })
    }

    private fun newChat() {
        messagesContainer.removeAllViews()
        input.text.clear()
        lastReply = ""
        currentChatId = "chat_${System.currentTimeMillis()}"
        chatTitle.text = "محادثة جديدة"
        saveCurrentChat()
    }

    private fun showHistory() {
        val ids = getIndex()
        if (ids.isEmpty()) {
            Toast.makeText(this, "لا توجد محادثات محفوظة بعد", Toast.LENGTH_SHORT).show()
            return
        }

        val titles = ids.map { id ->
            getSharedPreferences(prefsName, MODE_PRIVATE)
                .getString("$id:title", "محادثة") ?: "محادثة"
        }

        AlertDialog.Builder(this)
            .setTitle("المحادثات المحفوظة")
            .setItems(titles.toTypedArray()) { _, which -> loadChat(ids[which]) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun loadChat(id: String) {
        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        val raw = prefs.getString("$id:messages", "[]") ?: "[]"
        val title = prefs.getString("$id:title", "محادثة") ?: "محادثة"

        messagesContainer.removeAllViews()
        currentChatId = id
        chatTitle.text = title
        lastReply = ""

        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) addMessage(arr.getString(i))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح المحادثة", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveCurrentChat() {
        if (currentChatId.isEmpty()) return
        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        val arr = JSONArray()
        for (i in 0 until messagesContainer.childCount) {
            (messagesContainer.getChildAt(i) as? TextView)?.let { arr.put(it.text.toString()) }
        }

        prefs.edit()
            .putString("$currentChatId:messages", arr.toString())
            .putString("$currentChatId:title", chatTitle.text.toString())
            .apply()

        val ids = getIndex().toMutableList()
        if (!ids.contains(currentChatId)) ids.add(0, currentChatId)
        prefs.edit().putString(indexKey, ids.joinToString("|")).apply()
    }

    private fun getIndex(): List<String> =
        getSharedPreferences(prefsName, MODE_PRIVATE)
            .getString(indexKey, "")!!
            .split("|").filter { it.isNotBlank() }

    private fun addAndSaveMessage(text: String) { addMessage(text); saveCurrentChat() }

    private fun addMessage(text: String) {
        messagesContainer.addView(TextView(this).apply {
            this.text = text
            textSize = 17f
            setPadding(16, 12, 16, 12)
        })
        scrollToBottom()
    }

    private fun replaceLastMessage(text: String) {
        if (messagesContainer.childCount > 0)
            (messagesContainer.getChildAt(messagesContainer.childCount - 1) as TextView).text = text
        else addMessage(text)
        scrollToBottom()
    }

    private fun startVoiceInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), RECORD_AUDIO_REQUEST)
            return
        }
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("ar"))
                putExtra(RecognizerIntent.EXTRA_PROMPT, "اتكلم الآن")
            }, SPEECH_REQUEST)
        } catch (_: Exception) {
            Toast.makeText(this, "ميزة التعرف على الصوت غير متاحة", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Use Activity Result API in a future cleanup pass")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SPEECH_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
                input.setText(it); input.setSelection(input.length()); sendText(it)
            }
        }
        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK) data?.data?.let { analyzeSelectedImage(it) }
    }

    private fun analyzeSelectedImage(uri: Uri) {
        addAndSaveMessage("أنت: 🖼️ أرسلت صورة")
        setBusy(true); addMessage("مساعد AI: جاري تحليل الصورة...")
        Thread {
            try {
                val stream = contentResolver.openInputStream(uri) ?: throw Exception("تعذر قراءة الصورة")
                val bitmap = BitmapFactory.decodeStream(stream) ?: throw Exception("الصورة غير صالحة")
                stream.close()
                val scale = minOf(1f, 1280f / maxOf(bitmap.width, bitmap.height))
                val resized = if (scale < 1f) Bitmap.createScaledBitmap(bitmap, (bitmap.width*scale).toInt(), (bitmap.height*scale).toInt(), true) else bitmap
                val out = ByteArrayOutputStream()
                resized.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, out)
                val dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)

                AiApiClient.analyzeImage(dataUrl, onSuccess = { reply ->
                    runOnUiThread {
                        replaceLastMessage("مساعد AI: $reply"); lastReply = reply
                        saveCurrentChat(); speakReply(reply); setBusy(false)
                    }
                }, onError = { error ->
                    runOnUiThread {
                        replaceLastMessage("مساعد AI: تعذر تحليل الصورة.")
                        saveCurrentChat(); Toast.makeText(this, error, Toast.LENGTH_LONG).show(); setBusy(false)
                    }
                })
            } catch (e: Exception) {
                runOnUiThread {
                    replaceLastMessage("مساعد AI: تعذر قراءة الصورة.")
                    saveCurrentChat(); Toast.makeText(this, e.message ?: "خطأ", Toast.LENGTH_LONG).show(); setBusy(false)
                }
            }
        }.start()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("ar"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts.language = Locale.getDefault()
            tts.setSpeechRate(0.95f)
        }
    }

    private fun speakReply(text: String) { if (::tts.isInitialized && text.isNotBlank()) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mosaed_reply") }

    private fun setBusy(busy: Boolean) {
        sendButton.isEnabled = !busy; imageButton.isEnabled = !busy; voiceButton.isEnabled = !busy
    }

    private fun scrollToBottom() {
        findViewById<ScrollView>(R.id.messagesScroll).post {
            findViewById<ScrollView>(R.id.messagesScroll).fullScroll(ScrollView.FOCUS_DOWN)
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
