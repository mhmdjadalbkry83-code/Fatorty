package com.mosaed.ai

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var messagesContainer: LinearLayout
    private lateinit var input: EditText
    private lateinit var sendButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        messagesContainer = findViewById(R.id.messagesContainer)
        input = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)

        sendButton.setOnClickListener {
            val message = input.text.toString().trim()
            if (message.isEmpty()) return@setOnClickListener

            addMessage("أنت: $message")
            input.text.clear()
            sendButton.isEnabled = false
            addMessage("مساعد AI: جاري التفكير...")

            AiApiClient.sendMessage(
                message = message,
                onSuccess = { reply ->
                    runOnUiThread {
                        replaceLastMessage("مساعد AI: $reply")
                        sendButton.isEnabled = true
                    }
                },
                onError = { error ->
                    runOnUiThread {
                        replaceLastMessage("مساعد AI: حصل خطأ في الاتصال بالخادم.")
                        Toast.makeText(this, error, Toast.LENGTH_LONG).show()
                        sendButton.isEnabled = true
                    }
                }
            )
        }
    }

    private fun addMessage(text: String) {
        val view = TextView(this).apply {
            this.text = text
            textSize = 17f
            setPadding(16, 12, 16, 12)
        }
        messagesContainer.addView(view)
        scrollToBottom()
    }

    private fun replaceLastMessage(text: String) {
        if (messagesContainer.childCount > 0) {
            (messagesContainer.getChildAt(messagesContainer.childCount - 1) as TextView).text = text
        } else {
            addMessage(text)
        }
        scrollToBottom()
    }

    private fun scrollToBottom() {
        val scroll = findViewById<ScrollView>(R.id.messagesScroll)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
