import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.MODEL || "gpt-5.6-luna";

app.use(cors());
app.use(express.json({ limit: "8mb" }));

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "mosaed-ai-server" });
});

async function callOpenAI(input) {
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({ model: MODEL, input })
  });

  const data = await response.json();

  if (!response.ok) {
    console.error("OpenAI error:", data);
    throw new Error(data?.error?.message || "OpenAI request failed");
  }

  return data.output_text || "";
}

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "message is required" });
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY is not configured on the server" });
    }

    const reply = await callOpenAI([
      {
        role: "system",
        content: [{ type: "input_text", text: "أنت مساعد ذكي عربي مفيد. أجب بوضوح وباختصار مناسب." }]
      },
      {
        role: "user",
        content: [{ type: "input_text", text: message }]
      }
    ]);

    res.json({ reply });
  } catch (error) {
    res.status(500).json({ error: error.message || "Server error" });
  }
});

app.post("/api/analyze-image", async (req, res) => {
  try {
    const imageData = String(req.body?.imageData || "").trim();
    const prompt = String(req.body?.prompt || "حلل الصورة واشرح ما يظهر فيها بالعربية.").trim();

    if (!imageData.startsWith("data:image/")) {
      return res.status(400).json({ error: "imageData must be a valid image data URL" });
    }

    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY is not configured on the server" });
    }

    const reply = await callOpenAI([
      {
        role: "user",
        content: [
          { type: "input_text", text: prompt },
          { type: "input_image", image_url: imageData }
        ]
      }
    ]);

    res.json({ reply });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || "Image analysis failed" });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Mosaed AI server running on port ${PORT}`);
});
