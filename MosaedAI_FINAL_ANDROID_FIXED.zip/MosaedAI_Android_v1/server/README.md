# Mosaed AI - الوسيط الآمن

المسارات:
- GET `/health`
- POST `/api/chat` للدردشة النصية
- POST `/api/analyze-image` لتحليل الصور

## تحليل الصور
يرسل تطبيق Android الصورة كـ Data URL إلى الخادم. الخادم يمررها إلى OpenAI ثم يعيد النص الناتج للتطبيق.

لا تضع مفتاح OpenAI داخل APK. استخدم `OPENAI_API_KEY` في `.env` على الخادم.

## التشغيل
npm install
انسخ `.env.example` إلى `.env`
ضع مفتاح OpenAI في `.env`
npm start

وعند نشر الخادم استخدم HTTPS.
