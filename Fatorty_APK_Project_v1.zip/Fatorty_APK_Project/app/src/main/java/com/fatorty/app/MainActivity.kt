package com.fatorty.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import java.util.Locale

data class Item(val name: String, val price: Double, val qty: Int)

class MainActivity : Activity() {
    private val items = mutableListOf<Item>()
    private lateinit var itemsBox: LinearLayout
    private lateinit var totalText: TextView
    private lateinit var invoiceNumber: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showInvoice()
    }

    private fun showInvoice() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "فتورتي"
            textSize = 30f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        invoiceNumber = TextView(this).apply {
            text = "رقم الفاتورة: FT-${System.currentTimeMillis().toString().takeLast(6)}"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        root.addView(invoiceNumber)

        val name = EditText(this).apply {
            hint = "اسم المنتج"
            textSize = 16f
        }
        root.addView(name)

        val price = EditText(this).apply {
            hint = "السعر بالجنيه"
            inputType = 2 or 8192
        }
        root.addView(price)

        val qty = EditText(this).apply {
            hint = "الكمية"
            inputType = 2
            setText("1")
        }
        root.addView(qty)

        val addButton = Button(this).apply {
            text = "إضافة المنتج"
            setOnClickListener {
                val n = name.text.toString().trim()
                val p = price.text.toString().toDoubleOrNull()
                val q = qty.text.toString().toIntOrNull()
                if (n.isEmpty() || p == null || q == null || p < 0 || q <= 0) {
                    Toast.makeText(this@MainActivity, "أدخل البيانات بشكل صحيح", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                items.add(Item(n, p, q))
                name.text.clear()
                price.text.clear()
                qty.setText("1")
                refresh()
            }
        }
        root.addView(addButton)

        itemsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 15, 0, 10)
        }
        root.addView(itemsBox, LinearLayout.LayoutParams(-1, 0, 1f))

        totalText = TextView(this).apply {
            textSize = 22f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 12, 0, 12)
        }
        root.addView(totalText)

        val clear = Button(this).apply {
            text = "فاتورة جديدة"
            setOnClickListener {
                items.clear()
                invoiceNumber.text = "رقم الفاتورة: FT-${System.currentTimeMillis().toString().takeLast(6)}"
                refresh()
            }
        }
        root.addView(clear)

        setContentView(root)
        refresh()
    }

    private fun refresh() {
        itemsBox.removeAllViews()
        var total = 0.0
        items.forEachIndexed { index, item ->
            val line = item.price * item.qty
            total += line
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 7, 0, 7)
            }
            val text = TextView(this).apply {
                text = "${index + 1}. ${item.name} — ${money(item.price)} × ${item.qty} = ${money(line)} جنيه"
                textSize = 16f
            }
            row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
            val del = Button(this).apply {
                text = "حذف"
                setOnClickListener { items.removeAt(index); refresh() }
            }
            row.addView(del)
            itemsBox.addView(row)
        }
        totalText.text = "الإجمالي: ${money(total)} جنيه"
    }

    private fun money(value: Double) = String.format(Locale.US, "%.2f", value)
}
